

/**
 * @author user
 * @version 1.0
 * @created 29-Dec-2020 11:16:57 PM
 */
public class DeleteUser {

	private String MembershipNo;
	public AdminController m_AdminController;

	public DeleteUser(){

	}

	public void finalize() throws Throwable {

	}

	public void Delete(){

	}

}