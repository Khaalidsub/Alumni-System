

/**
 * @author user
 * @version 1.0
 * @created 29-Dec-2020 11:17:09 PM
 */
public class SignIn {

	private String ID;
	private String password;
	public SignInController m_SignInController;

	public SignIn(){

	}

	public void finalize() throws Throwable {

	}

	public void accessSignInScreen(){

	}

	public void dispSigned(){

	}

	/**
	 * 
	 * @param ID
	 * @param password
	 */
	public String LoginAcc(String ID, String password){
		return "";
	}

	public void userNotFound(){

	}

	public void wrongLogin(){

	}

}