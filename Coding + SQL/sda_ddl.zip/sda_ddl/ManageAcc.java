

/**
 * @author user
 * @version 1.0
 * @created 29-Dec-2020 11:17:02 PM
 */
public class ManageAcc {

	private String ID;
	public AlumniController m_AlumniController;

	public ManageAcc(){

	}

	public void finalize() throws Throwable {

	}

	public void dispUserAcc(){

	}

	public void EditProf(){

	}

	public String enterDetails(){
		return "";
	}

	/**
	 * 
	 * @param newPass
	 */
	public String newPass(String newPass){
		return "";
	}

	public void oldPassMatch(){

	}

	public void onClickEdit(){

	}

	public void onClickManage(){

	}

	/**
	 * 
	 * @param newPass
	 */
	public String reEnterPass(String newPass){
		return "";
	}

	public void retDetails(){

	}

	public String retPicture(){
		return "";
	}

	/**
	 * 
	 * @param password
	 */
	public String UpdatePass(String password){
		return "";
	}

	public void UpdatePic(){

	}

}