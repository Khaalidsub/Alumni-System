

/**
 * @author Asus
 * @version 1.0
 * @created 29-Dec-2020 11:17:07 PM
 */
public class RegisterController {

	public Database m_Database;

	public RegisterController(){

	}

	public void finalize() throws Throwable {

	}

	public bool validate(){
		return null;
	}

	/**
	 * 
	 * @param Address
	 * @param CurrentJob
	 * @param PreviousJob
	 * @param Email/Phone
	 * @param GraduateYear
	 * @param Name
	 * @param password
	 * @param SalaryCurrent
	 * @param SalaryPrevious
	 * @param Status
	 */
	public void validateDetails(String Address, String CurrentJob, String PreviousJob, String Email/Phone, int GraduateYear, String Name, String password, double SalaryCurrent, double SalaryPrevious, String Status){

	}

}