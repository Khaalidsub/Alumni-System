

/**
 * @author Asus
 * @version 1.0
 * @created 29-Dec-2020 11:16:55 PM
 */
public class Database {

	public Database(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param password
	 */
	public String checkPass(String password){
		return "";
	}

	/**
	 * 
	 * @param Email/Phone
	 */
	public String getUserDetails(String Email/Phone){
		return "";
	}

	/**
	 * 
	 * @param ID
	 */
	public void removeUserDetails(String ID){

	}

	/**
	 * 
	 * @param Name
	 * @param password
	 * @param Address
	 * @param CurrentJob
	 * @param Email/Phone
	 * @param GraduateYear
	 * @param PreviousJob
	 * @param SalaryCurrent
	 * @param SalaryPrevious
	 * @param Status
	 */
	public void safeUserDetails(String Name, String password, String Address, String CurrentJob, String Email/Phone, int GraduateYear, String PreviousJob, double SalaryCurrent, double SalaryPrevious, String Status){

	}

	/**
	 * 
	 * @param newPass
	 */
	public String savePass(String newPass){
		return "";
	}

	public String savePic(){
		return "";
	}

	/**
	 * 
	 * @param ID
	 */
	public String searchUser(String ID){
		return "";
	}

	/**
	 * 
	 * @param ID
	 * @param password
	 */
	public String searchUserInfo(String ID, String password){
		return "";
	}

}