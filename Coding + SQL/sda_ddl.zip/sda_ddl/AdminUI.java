

/**
 * @author Asus
 * @version 1.0
 * @created 29-Dec-2020 11:16:49 PM
 */
public class AdminUI {

	public Register m_Register;
	public DeleteUser m_DeleteUser;

	public AdminUI(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param ID
	 */
	public String deleteUser(String ID){
		return "";
	}

	public void notFound(){

	}

	/**
	 * 
	 * @param ID
	 */
	public String searchName(String ID){
		return "";
	}

	/**
	 * 
	 * @param ID
	 */
	public String searchUser(String ID){
		return "";
	}

	public void userDeleted(){

	}

	public void userDeleted(){

	}

	public void userFound(){

	}

}