

/**
 * @author Asus
 * @version 1.0
 * @created 29-Dec-2020 11:17:07 PM
 */

public class RegisterController {

    boolean valid = true;
	public Database m_Database;

	public RegisterController(){

	}

	public void finalize() throws Throwable {

	}

	public boolean validate(){
		return valid ;
	}

	/**
	 * 
	 * @param Address
	 * @param CurrentJob
	 * @param PreviousJob
	 * @param Email/Phone
	 * @param GraduateYear
	 * @param Name
	 * @param password
	 * @param SalaryCurrent
	 * @param SalaryPrevious
	 * @param Status
	 */
	public void validateDetails(String Address, String CurrentJob, String PreviousJob, String Email, String Phone, int GraduateYear, String Name, String password, double SalaryCurrent, double SalaryPrevious, String Status){

	}

}