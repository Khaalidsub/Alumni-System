

/**
 * @author Asus
 * @version 1.0
 * @created 29-Dec-2020 11:16:59 PM
 */
public class Homepage {

	public SignIn m_SignIn;
	public Register m_Register;

	public void Homepage1(){

	}

	public void finalize() throws Throwable {

	}

	public void onClickReg(){

	}

	public void onClickSignin(){

	}

}