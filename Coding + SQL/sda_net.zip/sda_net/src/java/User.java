

/**
 * @author Asus
 * @version 1.0
 * @created 29-Dec-2020 11:17:13 PM
 */
public class User {

	public Register m_Register;

	public User(){

	}

	public void finalize() throws Throwable {

	}

	public void dispError(){

	}

	public void displaySignInScreen(){

	}

	public void dispPic(){

	}

	public void dispSuccess(){

	}

	public void dispUserAcc(){

	}

	public void showSuggestions(){

	}

}