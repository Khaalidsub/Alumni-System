

/**
 * @author user
 * @version 1.0
 * @created 29-Dec-2020 11:17:05 PM
 */
public class Register {

	private String Address;
	private String CurrentJob;
	private String Email;
        private String Phone;
	private int GraduateYear;
	private String Name;
	private String password;
	private String PreviousJob;
	private double SalaryCurrent;
	private double SalaryPrevious;
	private String Status;
	public SignIn m_SignIn;
	public RegisterController m_RegisterController;

	public void Register(){

	}

	public void finalize() throws Throwable {

	}

	public void accessRegisterScreen(){

	}

	public void displayExample(){

	}

	public void errorMessage(){

	}

	/**
	 * 
	 * @param Address
	 * @param CurrentJob
	 * @param Email/Phone
	 * @param GraduateYear
	 * @param Name
	 * @param password
	 * @param PreviousJob
	 * @param SalaryCurrent
	 * @param SalaryPrevious
	 * @param Status
	 */
	public String RegisterNew(String Address, String CurrentJob, String Email, String Phone, int GraduateYear, String Name, String password, String PreviousJob, double SalaryCurrent, double SalaryPrevious, String Status){
             return "";  
	}

	public void successMessage(){

	}

}