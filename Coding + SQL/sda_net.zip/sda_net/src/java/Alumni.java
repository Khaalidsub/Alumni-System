

/**
 * @author user
 * @version 1.0
 * @created 29-Dec-2020 11:16:51 PM
 */
public class Alumni extends User {

	private String AlumniAddress;
	protected String AlumniCurrentJob;
	protected String AlumniEmail;
	protected int AlumniGraduateYear;
	protected String AlumniLocation;
	protected String AlumniMembershipNo;
	protected String AlumniName;
	private String AlumniPhoneNo;
	private String AlumniPreviousJob;
	private double AlumniSalaryPrevious;
	private double AlumniSalaryuCurrent;
	protected String AlumniSatus;
	public Homepage m_Homepage;
       

	public Alumni(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	public void dispError(){

	}

	public void displaySignInScreen(){

	}

	public void dispPic(){

	}

	public void dispReqScreen(){

	}

	public void dispSuccess(){

	}

	public void dispUserAcc(){

	}
       
	
}