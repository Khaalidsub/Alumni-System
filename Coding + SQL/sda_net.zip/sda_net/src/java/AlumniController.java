

/**
 * @author Asus
 * @version 1.0
 * @created 29-Dec-2020 11:16:53 PM
 */
public class AlumniController {

	public Database m_Database;

	public void AlumniController(){

	}

	public void finalize() throws Throwable {

	}

	public boolean checkBothNew(){
		return false;
	}

	public void checkPicFormat(){

	}

	public void editProfile(){

	}

	/**
	 * 
	 * @param Name
	 * @param password
	 * @param Address
	 * @param CurrentJob
	 * @param PreviousJob
	 * @param Email/Phone
	 * @param GraduateYear
	 * @param SalaryCurrent
	 * @param SalaryPrevious
	 * @param Status
         * @param Phone
	 */
    
        
	public String enterDetails(String Name, String password, String Address, String CurrentJob, String PreviousJob, String Email, String Phone, int GraduateYear, double SalaryCurrent, double SalaryPrevious, String Status){
		return " ";
	}

	/**
	 * 
	 * @param newPass
	 * @param reenterPass
	 */
	public String newPassReenter(String newPass, String reenterPass){
		return " ";
	}

	/**
	 * 
	 * @param newPass
	 */
	public String newPassword(String newPass){
		return "";
	}

	/**
	 * 
	 * @param password
	 */
	public String oldPass(String password){
		return "";
	}

	public void reqUserInfo(){

	}

	public void retUserDetails(){

	}

	public void updatePass(){

	}

	public void uploadPic(){

	}

	public String uploadPicture(){
		return "";
	}

}