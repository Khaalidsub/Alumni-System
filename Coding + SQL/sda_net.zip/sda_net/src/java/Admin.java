

/**
 * @author user
 * @version 1.0
 * @created 29-Dec-2020 11:16:44 PM
 */
public class Admin extends User {

	private String AdminEmail;
	private String AdminID;
	private String AdminName;
	public AdminUI m_AdminUI;

	public Admin(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	public void dispError(){

	}

	public void displayError(){

	}

	public void displaySignInScreen(){

	}

	public void displaySuccess(){

	}

	public void displayUser(){

	}

	public void dispPic(){

	}

	public void dispSuccess(){

	}

	public void dispUserAcc(){

	}

	public void showSuggestions(){

	}

}