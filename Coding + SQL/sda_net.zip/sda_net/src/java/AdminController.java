

/**
 * @author Asus
 * @version 1.0
 * @created 29-Dec-2020 11:16:47 PM
 */
public class AdminController {

	public Database m_Database;

	public AdminController(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param ID
	 */
	public String delete(String ID){
		return "";
	}

	/**
	 * 
	 * @param ID
	 */
	public String SearchUsername(String ID){
		return "";
	}

}