

/**
 * @author Asus
 * @version 1.0
 * @created 29-Dec-2020 11:17:11 PM
 */
public class SignInController {

	public Database m_Database;
	public ManageAcc m_ManageAcc;

	public SignInController(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param ID
	 * @param password
	 */
	public String validateUser(String ID, String password){
		return "";
	}

}